﻿namespace EPAWOFService {
    
    
    public partial class EPAResults {
    }
}
