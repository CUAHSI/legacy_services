﻿namespace WaterOneFlow.Service {


    partial class DataValuesTables
    {
    }
}
