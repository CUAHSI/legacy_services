﻿namespace WaterOneFlow.Service {
    
    
    public partial class CoreTables {
        partial class SeriesCatalogDataTable
        {
        }
    
        partial class UnitsDataTable
        {
        }
    }
}
