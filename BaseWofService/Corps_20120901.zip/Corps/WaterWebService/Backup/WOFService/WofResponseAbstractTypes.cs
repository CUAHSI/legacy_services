using System;
using System.Collections.Generic;
using System.Text;

namespace WaterOneFlow.Service
{
    namespace Abstract {
    public  interface VariablesResponseType{}
        public interface SiteInfoResponseType { }
        public interface TimeSeriesResponseType { }

    
    }
}
