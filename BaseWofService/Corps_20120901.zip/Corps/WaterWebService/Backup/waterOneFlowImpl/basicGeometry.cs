using System;
using System.Collections.Generic;
using System.Text;

namespace WaterOneFlowImpl.geom
{
    public abstract class  basicGeometry 
    {
        public  static String geomNetworkID = "GEOM";
        public static String geomType;
        public static String geomFormat;
        public static String CoordSeparator = " ";
        public static String XYPairSeparator = ",";


    }
}
